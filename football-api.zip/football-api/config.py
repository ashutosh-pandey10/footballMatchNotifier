
# Enter the team that you want to follow. 
team_name = 'real madrid'
# Enter your api key
api_key = 'cc87df6c7c0744fdbbf070734fd5d1fb'
# Enter how many days ahead do you want to check for matches. 
timeframe = 15
