source /home/mouse10/miniconda3/bin/activate
python /home/mouse10/football-api/main.py 